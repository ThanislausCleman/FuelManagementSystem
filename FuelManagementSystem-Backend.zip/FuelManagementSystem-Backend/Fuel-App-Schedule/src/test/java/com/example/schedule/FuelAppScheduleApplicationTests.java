package com.example.schedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelAppScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
