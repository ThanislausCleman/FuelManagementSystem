package com.example.dispatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelAppDispatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
