package com.example.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuelAppOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuelAppOrderApplication.class, args);
	}

}
